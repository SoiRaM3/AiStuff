# SoiRaM Core

An AI assistant with chaotic creativity and cinematic terminal interface. Built with FastAPI + Ollama.

## 💻 To Run

1. Install Python packages:
   ```
   pip install -r requirements.txt
   ```

2. Start locally:
   ```
   uvicorn main:app --reload
   ```

3. Access on [http://localhost:8000](http://localhost:8000)

## 🔧 Deployment on EC2

1. Clone repo:
   ```
   git clone https://github.com/you/soiram-core.git
   cd soiram-core
   ```

2. Install requirements:
   ```
   pip install -r requirements.txt
   ```

3. Start:
   ```
   uvicorn main:app --host 0.0.0.0 --port 8000
   ```

4. Configure NGINX to reverse proxy to this service.

