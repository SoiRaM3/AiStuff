# 🔧 CORE FRAMEWORK
from fastapi import FastAPI, Request, Form
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from fastapi.staticfiles import StaticFiles

# 🛡 SESSION + STATE MGMT
from starlette.middleware.sessions import SessionMiddleware

# 🔒 ENV VARS + LOGGING
from dotenv import load_dotenv
import os
import logging
import random

# 🧠 AI INTEGRATION
from utils.query_llm import query_llm

# 🧭 Load environment variables
load_dotenv()

# 📦 INIT APP
app = FastAPI()

# 🛡️ SESSION COOKIES
app.add_middleware(SessionMiddleware, secret_key=os.getenv("SOIRAM_SESSION_KEY", "S0iR@M_c00k13z!"))

# 🎨 ASSETS + TEMPLATES
templates = Jinja2Templates(directory="templates")
app.mount("/static", StaticFiles(directory="static"), name="static")

# 🧾 Logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("soiram")

# 🔧 ROUTES

@app.get("/", response_class=HTMLResponse)
@app.get("/webui", response_class=HTMLResponse)
async def webui_embed(request: Request):
    return templates.TemplateResponse("webui.html", {
        "request": request,
        "url": "http://localhost:7860"  # Replace as needed
    })

async def mode_selector(request: Request):
    nickname = request.session.get("nickname", "Guest")
    return templates.TemplateResponse("mode_selector.html", {
        "request": request,
        "nickname": nickname
    })

@app.post("/chat", response_class=HTMLResponse)
async def chat(request: Request, mode: str = Form(...), prompt: str = Form(...)):
    nickname = request.session.get("nickname", "User")

    try:
        response = await query_llm(prompt, mode)
    except Exception as e:
        logger.error(f"LLM Error: {e}")
        response = f"[Error connecting to SoiRaM core LLM: {str(e)}]"

    return templates.TemplateResponse("chat.html", {
        "request": request,
        "response": response,
        "mode": mode,
        "nickname": nickname,
        "prompt": prompt
    })


@app.get("/boot", response_class=HTMLResponse)
async def boot_screen(request: Request):
    nickname = request.session.get("nickname", "Operator")
    logs = [
        ">> Initializing SoiRaM core modules...",
        ">> Verifying neural trust link...",
        ">> Memory integrity: stable",
        ">> Mood calibration: chaotic good",
        f">> User authenticated: {nickname}"
    ]
    return templates.TemplateResponse("boot.html", {
        "request": request,
        "nickname": nickname,
        "logs": logs
    })


@app.get("/webui", response_class=HTMLResponse)
async def webui_embed(request: Request):
    return templates.TemplateResponse("webui.html", {
        "request": request,
        "url": "http://localhost:7860"  # Replace with your WebUI if needed
    })
